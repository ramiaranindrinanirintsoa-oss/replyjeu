package mg.replyjeu

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayManager(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var root: View? = null
    private var recognizer: SpeechRecognizer? = null
    private val hideRunnable = Runnable { hide() }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun show(title: String, message: String, send: (String) -> Boolean) {
        if (!Settings.canDrawOverlays(ctx)) return
        handler.post { build(title, message, send) }
    }

    fun hide() {
        handler.removeCallbacks(hideRunnable)
        recognizer?.destroy()
        recognizer = null
        root?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        root = null
    }

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = label
        textSize = 14f
        setTextColor(Color.WHITE)
        setPadding(dp(14), dp(9), dp(14), dp(9))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#3C4043"))
            cornerRadius = dp(18).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { rightMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun build(title: String, message: String, send: (String) -> Boolean) {
        hide()

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2202124"))
                cornerRadius = dp(18).toFloat()
            }
        }

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleView = TextView(ctx).apply {
            text = title
            textSize = 15f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
        }
        header.addView(
            titleView,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        val closeView = TextView(ctx).apply {
            text = "✕"
            textSize = 18f
            setTextColor(Color.LTGRAY)
            setPadding(dp(14), dp(2), dp(4), dp(2))
            setOnClickListener { hide() }
        }
        header.addView(closeView)

        val body = TextView(ctx).apply {
            text = message
            textSize = 14f
            setTextColor(Color.parseColor("#E0E0E0"))
            maxLines = 3
            setPadding(0, dp(4), 0, 0)
        }

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }
        val scroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }

        fun doSend(text: String) {
            val ok = send(text)
            Toast.makeText(ctx, if (ok) "Lasa ✓" else "Tsy lasa", Toast.LENGTH_SHORT).show()
            hide()
        }

        for (r in Prefs.replies(ctx)) {
            row.addView(chip(r) { doSend(r) })
        }
        row.addView(chip("🎤") { listen(body, row) { t -> doSend(t) } })

        card.addView(header)
        card.addView(body)
        card.addView(scroll)

        val wrapper = FrameLayout(ctx).apply {
            setPadding(dp(10), dp(10), dp(10), 0)
            addView(card)
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP

        try {
            wm.addView(wrapper, lp)
            root = wrapper
            handler.postDelayed(hideRunnable, 15000)
        } catch (e: Exception) {
        }
    }

    private fun listen(body: TextView, row: LinearLayout, onText: (String) -> Unit) {
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(ctx, "Omeo alalana mikrô ao amin'ny app Reply Jeu aloha", Toast.LENGTH_LONG).show()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            Toast.makeText(ctx, "Tsy misy fanekena feo amin'ity finday ity", Toast.LENGTH_LONG).show()
            return
        }

        handler.removeCallbacks(hideRunnable)
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r

        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                body.text = "🎤 Mihaino..."
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                body.text = "Tsy re. Tsindrio 🎤 indray."
                handler.postDelayed(hideRunnable, 15000)
            }

            override fun onResults(results: Bundle?) {
                val t = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (t.isNullOrBlank()) {
                    body.text = "Tsy re. Tsindrio 🎤 indray."
                } else {
                    body.text = "“$t”"
                    row.removeAllViews()
                    row.addView(chip("Alefa ✓") { onText(t) })
                    row.addView(chip("Foana") { hide() })
                }
                handler.postDelayed(hideRunnable, 20000)
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.lang(ctx))
        }
        r.startListening(intent)
    }
}
