package mg.replyjeu

import android.content.Context

object Prefs {
    val DEFAULT_REPLIES = listOf(
        "Milalao aho, mody afaka kelikely",
        "Ok",
        "Aoriana kely",
        "Tsy afaka mamaly izao"
    )

    private fun sp(c: Context) = c.getSharedPreferences("replyjeu", Context.MODE_PRIVATE)

    fun replies(c: Context): List<String> {
        val s = sp(c).getString("replies", null) ?: return DEFAULT_REPLIES
        return s.split("\n").map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { DEFAULT_REPLIES }
    }

    fun setReplies(c: Context, text: String) {
        sp(c).edit().putString("replies", text).apply()
    }

    fun lang(c: Context): String = sp(c).getString("lang", "fr-FR") ?: "fr-FR"

    fun setLang(c: Context, v: String) {
        sp(c).edit().putString("lang", v).apply()
    }

    fun enabled(c: Context): Boolean = sp(c).getBoolean("enabled", true)

    fun setEnabled(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("enabled", v).apply()
    }
}
