package mg.replyjeu

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {

    private lateinit var overlay: OverlayManager
    private val muted = HashMap<String, Long>()

    companion object {
        private val KNOWN = mapOf(
            "com.whatsapp" to "WhatsApp",
            "com.whatsapp.w4b" to "WhatsApp Business",
            "com.facebook.orca" to "Messenger",
            "com.facebook.mlite" to "Messenger Lite",
            "com.google.android.apps.messaging" to "SMS",
            "com.samsung.android.messaging" to "SMS",
            "com.android.mms" to "SMS"
        )
    }

    override fun onCreate() {
        super.onCreate()
        overlay = OverlayManager(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.enabled(this)) return
        if (sbn.packageName == packageName) return

        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val appName = KNOWN[sbn.packageName]
        if (appName == null && n.category != Notification.CATEGORY_MESSAGE) return

        val key = sbn.key
        val until = muted[key]
        if (until != null && System.currentTimeMillis() < until) return

        val action = findReplyAction(n) ?: return

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        val header = if (appName != null) "$appName • $title" else title

        overlay.show(header, text) { reply ->
            muted[key] = System.currentTimeMillis() + 6000
            sendReply(action, reply)
        }
    }

    private fun findReplyAction(n: Notification): Notification.Action? {
        val all = mutableListOf<Notification.Action>()
        n.actions?.let { all.addAll(it) }
        all.addAll(Notification.WearableExtender(n).actions)
        return all.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
    }

    private fun sendReply(action: Notification.Action, text: String): Boolean {
        return try {
            val inputs = action.remoteInputs
            val intent = Intent()
            val results = Bundle()
            for (ri in inputs) {
                results.putCharSequence(ri.resultKey, text)
            }
            RemoteInput.addResultsToIntent(inputs, intent, results)
            action.actionIntent.send(this, 0, intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
