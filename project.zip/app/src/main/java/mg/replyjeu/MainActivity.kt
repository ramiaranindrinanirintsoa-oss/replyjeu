package mg.replyjeu

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var repliesBox: EditText
    private lateinit var langBox: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 14f): TextView = TextView(this).apply {
        text = t
        textSize = size
        setPadding(0, dp(12), 0, dp(4))
    }

    private fun button(t: String, onClick: () -> Unit): Button = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }

        col.addView(label("Reply Jeu", 26f))
        col.addView(label("Mamaly message (WhatsApp, Messenger, SMS) rehefa milalao."))

        status = label("")
        col.addView(status)

        col.addView(button("1. Alalana notification") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(button("2. Alalana mampiseho eo ambonin'ny app hafa") {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        })
        col.addView(button("3. Alalana mikrô (ho an'ny feo)") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })

        val sw = Switch(this)
        sw.text = "Mavitrika"
        sw.isChecked = Prefs.enabled(this)
        sw.setOnCheckedChangeListener { _, checked -> Prefs.setEnabled(this, checked) }
        sw.setPadding(0, dp(16), 0, dp(8))
        col.addView(sw)

        col.addView(label("Valiny haingana (iray isaky ny andalana):"))
        repliesBox = EditText(this)
        repliesBox.setText(Prefs.replies(this).joinToString("\n"))
        repliesBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        repliesBox.minLines = 4
        col.addView(repliesBox)

        col.addView(label("Fiteny ho an'ny feo (ohatra fr-FR, en-US):"))
        langBox = EditText(this)
        langBox.setText(Prefs.lang(this))
        langBox.setSingleLine(true)
        col.addView(langBox)

        col.addView(button("Tehirizo") {
            Prefs.setReplies(this, repliesBox.text.toString())
            val l = langBox.text.toString().trim()
            Prefs.setLang(this, if (l.isEmpty()) "fr-FR" else l)
            Toast.makeText(this, "Voatahiry ✓", Toast.LENGTH_SHORT).show()
        })

        col.addView(button("Andramo (Test)") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Omeo ny alalana n°2 aloha", Toast.LENGTH_LONG).show()
            } else {
                OverlayManager(this).show("Test • WhatsApp", "Salama! Mbola milalao ve ianao?") { true }
            }
        })

        col.addView(
            label(
                "Torohevitra: esory ny famerana batterie ho an'ity app ity " +
                    "(Paramètres > Apps > Reply Jeu > Batterie > Tsy voafetra), " +
                    "mba tsy hijanona ao ambadika."
            )
        )

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun refresh() {
        val listeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        val n = listeners.contains(packageName)
        val o = Settings.canDrawOverlays(this)
        val m = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        fun mark(b: Boolean) = if (b) "✅" else "❌"
        status.text = "${mark(n)} Notification    ${mark(o)} Overlay    ${mark(m)} Mikrô"
    }
}
